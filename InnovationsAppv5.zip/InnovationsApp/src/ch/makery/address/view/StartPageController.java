package ch.makery.address.view;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import application.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import ch.makery.address.view.SymptomsTabController;

public class StartPageController {
	
	@FXML
	private TextField usernameTextField;
	
	@FXML
	private TabPane tabPane;
	
	@FXML
	private Tab tab1, tab2, tab3, tab4, tab5, tab6;
	
//	@FXML
//	private AnchorPane embeddedSymptomsPane;
	
//	@FXML
//	private Parent embeddedSymptomsTab;
	
	@FXML
	private SymptomsTabController embeddedSymptomsTabController;
	
	@FXML
	private PasswordField passwordTextField;
	
	@FXML
	private Text windowHeaderText;
		
	@FXML
	private Button loginButton, trackButton, statButton, medButton, infoButton, chatButton, thingoButton;
	
	@FXML
	private ImageView trackButtonIm, statButtonIm, medButtonIm, infoButtonIm, chatButtonIm, thingoButtonIm;
	
	private Stage primaryStage;
	
	@FXML
	private void onLoginClick() {
		String username = usernameTextField.getText();
		String password = passwordTextField.getText();
		
		Boolean userValid = false;
		Boolean passValid = false;
		Boolean loginValid = false;
		int count = 0;
		
		//Read the password log file
		String fileName = "bin/userData.txt";
		String currLine = null;
		try {
            FileReader fileReader = new FileReader(fileName);

            BufferedReader bufferedReader = new BufferedReader(fileReader);

            while((currLine = bufferedReader.readLine()) != null) {
                if (count == 0){
                	if (currLine.equals(username)) {
                		userValid = true;
                		System.out.println("Valid: " + username);
                	}else {
                		System.out.println("Invalid" + currLine + username);
                	}
                }
                else {
                	if (userValid && currLine.equals(password)) {
                		passValid = true;
                	}
                }
                if (userValid && passValid) {
                	loginValid = true;
                	break;
                }
                count = ((count + 1) % 2);
            } 
            
            if (loginValid) {
            	Main.windowNum = 1;
            	renewWindow();
            	//FXMLLoader loader2 = new FXMLLoader();
    			//loader2.setLocation(getClass().getResource("/ch/makery/address/view/SymptomsTab.fxml"));
    			//AnchorPane f2 = loader2.load();
    			//SymptomsTabController cont2 = (SymptomsTabController) loader2.getController();
    			//<fx:include fx:id="embeddedPane" source="SymptomsTab.fxml" />
            	//embeddedSymptomsTabController.setDateToday();
    			//embeddedSymptomsPaneID.setContent(FXMLLoader.load(getClass().getResource("/ch/makery/address/view/SymptomsTab.fxml")));
    			//cont2.setDateToday();
            	//embeddedSymptomsTabController.setDateToday();
            } else {
            	System.out.println("Username or Password Invalid"); //Make this appear somehow
            }
            
            bufferedReader.close();    
		}
		catch(FileNotFoundException ex) {
            System.out.println("File read error: " + fileName + " does not exist.");               
        }
		catch(IOException ex) {
            System.out.println("Error reading file " + fileName);                  
        }
	}
	
	
	public void renewWindow() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/ch/makery/address/view/MainWindow.fxml"));//ch.makery.address.view.
			AnchorPane root = (AnchorPane) loader.load();
			//StartPageController controller = loader.getController();
			//controller.setPrimaryStage(primaryStage);
			Scene scene = new Scene(root,390,660);
			primaryStage.setScene(scene);
			primaryStage.show();
    	} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
/*	public void setDateToday() {
		Date date = new Date();
		String dateStr = date.toString().toUpperCase();
		String month = dateStr.substring(4,7);
		String year = dateStr.substring(25,29);
		String day = dateStr.substring(8,10);
		String completeStr = day + " " + month + " " + year;
		System.out.println(day + " " + month + " " + year);
		//Text fillStr = new Text(completeStr);
		//System.out.println(dateYearString.getText());
		//embeddedPaneController.dateYearString.setText("Wololo");
		dateYearString.setDate();
	}
	
/*	public void setDateYearString(int button) {
		String currText = dateYearString.getText();
		switch(button) {
		case 0:	
			
			
		case 1:
			
			
			
		}
	}
	*/
	
	//trackButtonIm, statButtonIm, medButtonIm, infoButtonIm, chatButtonIm, thingoButtonIm
	@FXML
	private void onTrackClick() {
			//Set Main Colour
			windowHeaderText.setText("Symptoms");
			File file1 = new File("bin/MoodTrackingL.PNG");
			Image im1 = new Image(file1.toURI().toString());
			trackButtonIm.setImage(im1);
			trackButton.setStyle("-fx-background-color: rgb(233,50,102)");
			
			File file2 = new File("bin/Stats.PNG");
			Image im2 = new Image(file2.toURI().toString());
			statButtonIm.setImage(im2);
			statButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file3 = new File("bin/Medications.PNG");
			Image im3 = new Image(file3.toURI().toString());
			medButtonIm.setImage(im3);
			medButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file4 = new File("bin/Information.PNG");
			Image im4 = new Image(file4.toURI().toString());
			infoButtonIm.setImage(im4);
			infoButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file5 = new File("bin/Communications.PNG");
			Image im5 = new Image(file5.toURI().toString());
			chatButtonIm.setImage(im5);
			chatButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file6 = new File("bin/Thingo.PNG");
			Image im6 = new Image(file6.toURI().toString());
			thingoButtonIm.setImage(im6);
			thingoButton.setStyle("-fx-background-color: rgb(155,140,207)");
			tabPane.getSelectionModel().select(0);
	}
	@FXML
	private void onStatClick() {
			windowHeaderText.setText("Statistics");
			
			//Set Colours
			File file1 = new File("bin/MoodTracking.PNG");
			Image im1 = new Image(file1.toURI().toString());
			trackButtonIm.setImage(im1);
			trackButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file2 = new File("bin/StatsL.PNG");
			Image im2 = new Image(file2.toURI().toString());
			statButtonIm.setImage(im2);
			statButton.setStyle("-fx-background-color: rgb(233,50,102)");
			
			File file3 = new File("bin/Medications.PNG");
			Image im3 = new Image(file3.toURI().toString());
			medButtonIm.setImage(im3);
			medButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file4 = new File("bin/Information.PNG");
			Image im4 = new Image(file4.toURI().toString());
			infoButtonIm.setImage(im4);
			infoButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file5 = new File("bin/Communications.PNG");
			Image im5 = new Image(file5.toURI().toString());
			chatButtonIm.setImage(im5);
			chatButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file6 = new File("bin/Thingo.PNG");
			Image im6 = new Image(file6.toURI().toString());
			thingoButtonIm.setImage(im6);
			thingoButton.setStyle("-fx-background-color: rgb(155,140,207)");
			tabPane.getSelectionModel().select(1);
	}
	@FXML
	private void onMedClick() {
			windowHeaderText.setText("Medication");
			File file1 = new File("bin/MoodTracking.PNG");
			Image im1 = new Image(file1.toURI().toString());
			trackButtonIm.setImage(im1);
			trackButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file2 = new File("bin/Stats.PNG");
			Image im2 = new Image(file2.toURI().toString());
			statButtonIm.setImage(im2);
			statButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file3 = new File("bin/MedicationsL.PNG");
			Image im3 = new Image(file3.toURI().toString());
			medButtonIm.setImage(im3);
			medButton.setStyle("-fx-background-color: rgb(233,50,102)");
			
			File file4 = new File("bin/Information.PNG");
			Image im4 = new Image(file4.toURI().toString());
			infoButtonIm.setImage(im4);
			infoButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file5 = new File("bin/Communications.PNG");
			Image im5 = new Image(file5.toURI().toString());
			chatButtonIm.setImage(im5);
			chatButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file6 = new File("bin/Thingo.PNG");
			Image im6 = new Image(file6.toURI().toString());
			thingoButtonIm.setImage(im6);
			thingoButton.setStyle("-fx-background-color: rgb(155,140,207)");
			tabPane.getSelectionModel().select(2);
	}
	@FXML
	private void onInfoClick() {
			windowHeaderText.setText("Information");
			File file1 = new File("bin/MoodTracking.PNG");
			Image im1 = new Image(file1.toURI().toString());
			trackButtonIm.setImage(im1);
			trackButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file2 = new File("bin/Stats.PNG");
			Image im2 = new Image(file2.toURI().toString());
			statButtonIm.setImage(im2);
			statButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file3 = new File("bin/Medications.PNG");
			Image im3 = new Image(file3.toURI().toString());
			medButtonIm.setImage(im3);
			medButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file4 = new File("bin/InformationL.PNG");
			Image im4 = new Image(file4.toURI().toString());
			infoButtonIm.setImage(im4);
			infoButton.setStyle("-fx-background-color: rgb(233,50,102)");
			
			File file5 = new File("bin/Communications.PNG");
			Image im5 = new Image(file5.toURI().toString());
			chatButtonIm.setImage(im5);
			chatButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file6 = new File("bin/Thingo.PNG");
			Image im6 = new Image(file6.toURI().toString());
			thingoButtonIm.setImage(im6);
			thingoButton.setStyle("-fx-background-color: rgb(155,140,207)");
			tabPane.getSelectionModel().select(3);
	}
	@FXML
	private void onChatClick() {
			windowHeaderText.setText("Communication");
			File file1 = new File("bin/MoodTracking.PNG");
			Image im1 = new Image(file1.toURI().toString());
			trackButtonIm.setImage(im1);
			trackButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file2 = new File("bin/Stats.PNG");
			Image im2 = new Image(file2.toURI().toString());
			statButtonIm.setImage(im2);
			statButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file3 = new File("bin/Medications.PNG");
			Image im3 = new Image(file3.toURI().toString());
			medButtonIm.setImage(im3);
			medButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file4 = new File("bin/Information.PNG");
			Image im4 = new Image(file4.toURI().toString());
			infoButtonIm.setImage(im4);
			infoButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file5 = new File("bin/CommunicationsL.PNG");
			Image im5 = new Image(file5.toURI().toString());
			chatButtonIm.setImage(im5);
			chatButton.setStyle("-fx-background-color: rgb(233,50,102)");
			
			File file6 = new File("bin/Thingo.PNG");
			Image im6 = new Image(file6.toURI().toString());
			thingoButtonIm.setImage(im6);
			thingoButton.setStyle("-fx-background-color: rgb(155,140,207)");
			tabPane.getSelectionModel().select(4);
	}
	@FXML
	private void onThingoClick() {
			windowHeaderText.setText("Thingo");
			File file1 = new File("bin/MoodTracking.PNG");
			Image im1 = new Image(file1.toURI().toString());
			trackButtonIm.setImage(im1);
			trackButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file2 = new File("bin/Stats.PNG");
			Image im2 = new Image(file2.toURI().toString());
			statButtonIm.setImage(im2);
			statButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file3 = new File("bin/Medications.PNG");
			Image im3 = new Image(file3.toURI().toString());
			medButtonIm.setImage(im3);
			medButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file4 = new File("bin/Information.PNG");
			Image im4 = new Image(file4.toURI().toString());
			infoButtonIm.setImage(im4);
			infoButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file5 = new File("bin/Communications.PNG");
			Image im5 = new Image(file5.toURI().toString());
			chatButtonIm.setImage(im5);
			chatButton.setStyle("-fx-background-color: rgb(155,140,207)");
			
			File file6 = new File("bin/ThingoL.PNG");
			Image im6 = new Image(file6.toURI().toString());
			thingoButtonIm.setImage(im6);
			thingoButton.setStyle("-fx-background-color: rgb(233,50,102)");
			tabPane.getSelectionModel().select(5);
	}
	
	
	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}
}
