package ch.makery.address.view;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;

import application.Main;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;

public class SymptomsTabController {
	@FXML
	public Text dateYearString;
	
	@FXML
	public Button em0, em1, em2, em3, em4, em5, em6;
	
	@FXML
	public Button rightDateButton, leftDateButton;
	
	@FXML
	public TextArea diaryField;	
	
	public void setDateToday() {
		System.out.println(dateYearString.getText());
		Date date = new Date();
		String dateStr = date.toString();
		String month = dateStr.substring(4,7);
		String year = dateStr.substring(25,29);
		String day = dateStr.substring(8,10);
		String completeStr = day + " " + month + " " + year;
		System.out.println(day + " " + month + " " + year);
		//Text fillStr = new Text(completeStr);
		//System.out.println(dateYearString.getText());
		dateYearString.setText(completeStr);
		//System.out.println("MadeIt");
		System.out.println(dateYearString.getText());
	}

	public void onRightDateButtonClick() {
		String indicated = dateYearString.getText();
		Date date;
		String day;
		String month;
		String year;
		if (indicated.equals("Today")) {
			date = new Date();String dateStr = date.toString();
			day = dateStr.substring(8,10);
			month = dateStr.substring(4,7);
			year = dateStr.substring(25,29);
		} else {
			day = indicated.substring(0, 2);
			month = indicated.substring(3,6);
			year = indicated.substring(7,11);
		}
		int dayI = Integer.parseInt(day);
		if (indicated.equals("Today")){
			return;
		}
		if (dayI == 28 && month.toUpperCase().equals("FEB") && (Integer.parseInt(year) % 4 != 0)) {
			day = "01";
			month = "Mar";
		} 
		if (dayI == 29 && month.toUpperCase().equals("FEB") && (Integer.parseInt(year) % 4 == 0)) {
			day = "01";
			month = "Mar";
		} 
		switch(dayI) {
		case 31:	
			if (month.toUpperCase().equals("JAN")) {
				month = "Feb";
				day = "01";
				break;
			}
			if (month.toUpperCase().equals("MAR")) {
				month = "Apr";
				day = "01";
				break;
			}
			if (month.toUpperCase().equals("MAY")) {
				month = "Jun";
				day = "01";
				break;
			}
			if (month.toUpperCase().equals("JUL")) {
				month = "Aug";
				day = "01";
				break;
			}
			if (month.toUpperCase().equals("AUG")) {
				month = "Sep";
				day = "01";
				break;
			}
			if (month.toUpperCase().equals("OCT")) {
				month = "Nov";
				day = "01";
				break;
			}
			if (month.toUpperCase().equals("DEC")) {
				month = "Jan";
				day = "01";
				year = Integer.toString((Integer.parseInt(year) + 1));
				break;
			}
			return;
		case 30:
			if (month.toUpperCase().equals("APR")) {
				month = "Mar";
				day = "01";
				break;
			}
			if (month.toUpperCase().equals("JUN")) {
				month = "Jul";
				day = "01";
				break;
			}
			if (month.toUpperCase().equals("SEP")) {
				month = "Oct";
				day = "01";
				break;
			}
			if (month.toUpperCase().equals("NOV")) {
				month = "Dec";
				day = "01";
				break;
			}
		default: 
			dayI++;
			if (dayI < 10) {
				day = "0" + Integer.toString(dayI);
			} else {
				day = Integer.toString(dayI);
			}
		}
			
		Date dateN = new Date();
		String dateStrN = dateN.toString();
		String dayN = dateStrN.substring(8,10);
		String monthN = dateStrN.substring(4,7);
		String yearN = dateStrN.substring(25,29);
		//System.out.println(day + " " + dayN + " " + month + " " + monthN + " " + year + " " + yearN);
		String completeStr = dateStrN;
		if (dayN.equals(day) && monthN.equals(month) && yearN.equals(year)) {
			dateYearString.setText("Today");
		} else {
			completeStr = day + " " + month + " " + year;
			dateYearString.setText(completeStr);			
		}
		
		extractTrackData(completeStr.toUpperCase());
	}
	
	public void onLeftDateButtonClick() {
		String indicated = dateYearString.getText();
		Date date;
		String day;
		String month;
		String year;
		if (indicated.equals("Today")) {
			date = new Date();String dateStr = date.toString();
			day = dateStr.substring(8,10);
			month = dateStr.substring(4,7);
			year = dateStr.substring(25,29);
		} else {
			day = indicated.substring(0, 2);
			month = indicated.substring(3,6);
			year = indicated.substring(7,11);
		}
		int dayI = Integer.parseInt(day);
		if (dayI == 1) {
			switch(month.toUpperCase()) {
			case "MAR":		
				if (Integer.parseInt(year) % 4 == 0) {
					dayI = 29;
					month = "Feb";
				}
				break;
			case "DEC":
				month = "Nov";
				day = "30";
				break;
			case "NOV":
				month = "Oct";
				day = "31";
				break;
			case "OCT":
				month = "Sep";
				day = "31";
				break;
			case "SEP":
				month = "Aug";
				day = "30";
				break;
			case "AUG":
				month = "Jul";
				day = "31";
				break;
			case "JUL":
				month = "Jun";
				day = "30";
				break;
			case "JUN":
				month = "May";
				day = "31";
				break;
			case "MAY":
				month = "Apr";
				day = "30";
				break;
			case "APR":
				month = "Mar";
				day = "31";
				break;
			case "FEB":
				month = "Jan";
				day = "31";
				break;
			case "JAN":
				month = "Dec";
				year = Integer.toString((Integer.parseInt(year) - 1));
				day = "31";	
				break;
			}
		} else {
			dayI--;
			if (dayI < 10) {
				day = "0" + Integer.toString(dayI);
			} else {
				day = Integer.toString(dayI);
			}
		}
		
		dateYearString.setText("Today");
		String completeStr = day + " " + month + " " + year;
		dateYearString.setText(completeStr);			
		
		extractTrackData(completeStr.toUpperCase());
		
	}
	
	
	
	public void extractTrackData(String dayNum) {
		System.out.println("Started Checking Files");
		String fileName = "bin/user_dat.txt";
		String currLine = null;
		Boolean found = false;
		Boolean L1 = false;
		Boolean L2 = false;
		try {
	        FileReader fileReader = new FileReader(fileName);
	
	        BufferedReader bufferedReader = new BufferedReader(fileReader);
	
	        while((currLine = bufferedReader.readLine()) != null) {
            	if (currLine.equals(dayNum)) {
            		found = true;
            		continue;
            	}
            	
            	if (found && !L1)
            	{
            		System.out.println(currLine);
            		setEmote(currLine.substring(0, 1));            		
            		L1 = true;
            		continue;
            	}
            	
            	if (found && L1 && !L2) {
            		System.out.println(currLine + "Diary");
            		diaryField.setText(currLine);
            		L2 = true;
            	}
	            	
	        } 
	        
	        bufferedReader.close();  
	        System.out.println("Done Checking Lines");
	        
	        if (!found) {
	        	System.out.println("NotFound");
	        	resetFields(1);
	        }
		}
		catch(FileNotFoundException ex) {
	        System.out.println("File read error: " + fileName + " does not exist.");               
	    }
		catch(IOException ex) {
	        System.out.println("Error reading file " + fileName);                  
	    }
	}

	private void resetFields(int text) {
		// TODO Auto-generated method stub
		em0.setStyle("-fx-background-color: transparent");
		em1.setStyle("-fx-background-color: transparent");
		em2.setStyle("-fx-background-color: transparent");
		em3.setStyle("-fx-background-color: transparent");
		em4.setStyle("-fx-background-color: transparent");
		em5.setStyle("-fx-background-color: transparent");
		em6.setStyle("-fx-background-color: transparent");
		if (text == 1) {
			diaryField.setText("");
		}
	}

	private void setEmote(String inpt) {
		System.out.println(inpt);
		switch (inpt) {
		case "0": 
			resetFields(1);
			em0.setStyle("-fx-background-color: pink");
			System.out.println("Case 0");
			break;
		case "1":
			resetFields(1);
			em1.setStyle("-fx-background-color: pink");
			System.out.println("Case 1");
			break;
		case "2":
			resetFields(1);
			em2.setStyle("-fx-background-color: pink");
			System.out.println("Case 2");
			break;
		case "3":
			resetFields(1);
			em3.setStyle("-fx-background-color: pink");
			System.out.println("Case 3");
			break;
		case "4":
			resetFields(1);
			em4.setStyle("-fx-background-color: pink");
			System.out.println("Case 4");
			break;
		case "5":
			resetFields(1);
			em5.setStyle("-fx-background-color: pink");
			System.out.println("Case 5");
			break;
		case "6":
			resetFields(1);
			em6.setStyle("-fx-background-color: pink");
			System.out.println("Case 6");
			break;
		}
	}
	
	
	public void em0C() {
		resetFields(0);
		em0.setStyle("-fx-background-color: pink");
	}
	
	public void em1C() {
		resetFields(0);
		em1.setStyle("-fx-background-color: pink");
	}
	
	public void em2C() {
		resetFields(0);
		em2.setStyle("-fx-background-color: pink");
	}
	
	public void em3C() {
		resetFields(0);
		em3.setStyle("-fx-background-color: pink");
	}
	
	public void em4C() {
		resetFields(0);
		em4.setStyle("-fx-background-color: pink");
	}
	
	public void em5C() {
		resetFields(0);
		em5.setStyle("-fx-background-color: pink");
	}
	
	public void em6C() {
		resetFields(0);
		em6.setStyle("-fx-background-color: pink");
	}
}




