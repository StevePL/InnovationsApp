package ch.makery.address.view;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import application.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class StartPageController {
	
	@FXML
	private TextField usernameTextField;
	
	@FXML
	private PasswordField passwordTextField;
	
	@FXML
	private Text windowHeaderText;
		
	@FXML
	private Button loginButton;
	
	@FXML
	private Button trackButton;
	
	@FXML
	private Button statButton;
	
	@FXML
	private Button medButton;
	
	@FXML
	private Button infoButton;
	
	@FXML
	private Button chatButton;
	
	@FXML
	private Button thingoButton;
	
	private Stage primaryStage;
	
	@FXML
	private void onLoginClick() {
		String username = usernameTextField.getText();
		String password = passwordTextField.getText();
		
		Boolean userValid = false;
		Boolean passValid = false;
		Boolean loginValid = false;
		int count = 0;
		
		//Read the password log file
		String fileName = "D:\\Uni\\2017\\Semester 2 2017\\3230\\SoftwarePC\\InnovationsApp\\bin\\userData.txt";
		String currLine = null;
		try {
            FileReader fileReader = new FileReader(fileName);

            BufferedReader bufferedReader = new BufferedReader(fileReader);

            while((currLine = bufferedReader.readLine()) != null) {
                if (count == 0){
                	if (currLine.equals(username)) {
                		userValid = true;
                		System.out.println("Valid: " + username);
                	}else {
                		System.out.println("Invalid" + currLine + username);
                	}
                }
                else {
                	if (userValid && currLine.equals(password)) {
                		passValid = true;
                	}
                }
                if (userValid && passValid) {
                	loginValid = true;
                	break;
                }
                count = ((count + 1) % 2);
            } 
            
            if (loginValid) {
            	Main.windowNum = 1;
            	renewWindow();
            } else {
            	System.out.println("Username or Password Invalid"); //Make this appear somehow
            }
            
            bufferedReader.close();    
		}
		catch(FileNotFoundException ex) {
            System.out.println("File read error: " + fileName + " does not exist.");               
        }
		catch(IOException ex) {
            System.out.println("Error reading file " + fileName);                  
        }
	}
	
	
	public void renewWindow() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/ch/makery/address/view/MainWindow.fxml"));//ch.makery.address.view.
			AnchorPane root = (AnchorPane) loader.load();
			//StartPageController controller = loader.getController();
			//controller.setPrimaryStage(primaryStage);
			Scene scene = new Scene(root,390,660);
			primaryStage.setScene(scene);
			primaryStage.show();			
    	} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@FXML
	private void onTrackClick() {
			windowHeaderText.setText("Symptoms");
//			cheatIm.setImage("@../../../../../bin/tackIm.PNG");
	}
	@FXML
	private void onStatClick() {
			windowHeaderText.setText("Statistics");
	}
	@FXML
	private void onMedClick() {
			windowHeaderText.setText("Medication");
	}
	@FXML
	private void onInfoClick() {
			windowHeaderText.setText("Information");
	}
	@FXML
	private void onChatClick() {
			windowHeaderText.setText("Communication");
	}
	@FXML
	private void onThingoClick() {
			windowHeaderText.setText("Thingo");
	}
	
	
	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}
}
