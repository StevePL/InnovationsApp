package application;
	
import ch.makery.address.view.StartPageController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;


public class Main extends Application {
	public static int windowNum = 0; //1: Login; 2: Main window
	@Override
	public void start(Stage primaryStage) {
		try {
			
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/ch/makery/address/view/StartPage.fxml"));//ch.makery.address.view.
			AnchorPane root = (AnchorPane) loader.load();
			StartPageController controller = loader.getController();
			controller.setPrimaryStage(primaryStage);
			Scene scene = new Scene(root,390,660);
			primaryStage.setScene(scene);
			primaryStage.initStyle(StageStyle.UNDECORATED);
			primaryStage.show();
			
			//Font.loadFont(Main.class.getResource("Nunito-Regular.tff").toExternalForm(),10);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
